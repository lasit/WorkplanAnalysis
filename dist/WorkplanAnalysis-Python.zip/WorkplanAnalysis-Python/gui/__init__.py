"""GUI components for Workplan Analysis application."""
