"""Tab widgets for the main application interface."""
