"""Core data models and business logic for Workplan Analysis."""
